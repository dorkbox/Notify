/*
 * Copyright 2010 dorkbox, llc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package dorkbox.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.Enumeration;

public
class LocationResolver {
    public static
    File get() {
        return get(LocationResolver.class);
    }

    /**
     * Retrieve the location that this classfile was loaded from, or possibly null if the class was compiled on the fly
     */
    public static
    File get(Class<?> clazz) {
        // Get the location of this class
        ProtectionDomain pDomain = clazz.getProtectionDomain();
        CodeSource cSource = pDomain.getCodeSource();

        // file:/X:/workspace/XYZ/classes/  when it's in ide/flat
        // jar:/X:/workspace/XYZ/jarname.jar  when it's jar
        URL loc = cSource.getLocation();

        // we don't always have a protection domain (for example, when we compile classes on the fly, from memory)
        if (loc == null) {
            return null;
        }

        // Can have %20 as spaces (in winxp at least). need to convert to proper path from URL
        try {
            String fileName = URLDecoder.decode(loc.getFile(), "UTF-8");
            File file = new File(fileName).getAbsoluteFile()
                                          .getCanonicalFile();
            return file;

        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("Unable to decode file path!", e);
        } catch (IOException e) {
            throw new RuntimeException("Unable to get canonical file path!", e);
        }
    }

    public static
    URL getResource(final String resourceName) {

        URL resource = null;

        // maybe it's on disk? priority is disk
        File file = new File(resourceName);
        if (file.canRead()) {
            try {
                resource = file.toURI()
                               .toURL();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }

        if (resource == null) {
            resource = Thread.currentThread()
                                     .getContextClassLoader()
                                     .getResource(resourceName);
        }

        if (resource == null) {
            // maybe it's in the system classloader?
            resource = ClassLoader.getSystemResource(resourceName);
        }

        return resource;




//
//
//        ClassLoader contextClassLoader = Thread.currentThread()
//                                               .getContextClassLoader();
//        URL resource2 = contextClassLoader.getResource(resourceName);
////        URL resource = LocationResolver.getResource(fontsLocation);
//        if (resource2 == null) {
//            // error - missing folder
//        }
//        else {
//            File dir = null;
//            try {
//                URI uri = resource2.toURI();
//                System.err.println("uri " + uri);
//
//
//                Enumeration<URL> resources = contextClassLoader.getResources("resources");
//                while (resources.hasMoreElements()) {
//                    URL url = resources.nextElement();
//                    System.err.println("URL " + url);
//                    InputStream inputStream = url.openStream();
//
//                }
//
//
//
////                dir = new File(uri);
////                for (File nextFile : dir.listFiles()) {
////                    System.err.println("nextFile");
////                    // Do something with nextFile
////                }
//            } catch (URISyntaxException e) {
//                e.printStackTrace();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
    }

    public static
    Enumeration<URL> getResources(final String resourceName) {
        Enumeration<URL> resource = null;
        try {
            // maybe it's on disk? priority is disk
            File file = new File(resourceName);
            if (file.canRead()) {
                if (file.isDirectory()) {

                } else {

                }
//            try {
//                resource = file.toURI()
//                               .toURL();
//            } catch (MalformedURLException e) {
//                e.printStackTrace();
//            }
            }

            if (resource == null) {
                resource = Thread.currentThread()
                                 .getContextClassLoader()
                                 .getResources(resourceName);
            }

            if (resource == null) {
                // maybe it's in the system classloader?

                    resource = ClassLoader.getSystemResources(resourceName);

            }
        } catch (IOException e) {
            e.printStackTrace();
        }







// maybe it's on disk? priority is disk
//        if (new File(resourceName).exists()) {
//            resourceAsStream = new FileInputStream(name);
//        }
//
//        if (resourceAsStream == null) {
//            resourceAsStream = Thread.currentThread()
//                                     .getContextClassLoader()
//                                     .getResourceAsStream(name);
//        }
//        if (resourceAsStream == null) {
//            // maybe it's in the system classloader?
//            resourceAsStream = ClassLoader.getSystemResourceAsStream(name);
//        }

        return null;
    }

    /**
     * Retrieves the resource as a stream.
     * <p>
     * 1) checks the disk in the relative location to the executing app<br/>
     * 2) Checks the current thread context classloader <br/>
     * 3) Checks the Classloader system resource
     *
     * @param resourceName the name, including path information (Only valid '\' as the path separator)
     *
     * @return the resource stream, if it could be found, otherwise null.
     */
    public static
    InputStream getResourceAsStream(final String resourceName) {
        InputStream resourceAsStream = null;

        // maybe it's on disk? priority is disk
        if (new File(resourceName).canRead()) {
            try {
                resourceAsStream = new FileInputStream(resourceName);
            } catch (FileNotFoundException e) {
                // shouldn't happen, but if there is something wonky...
                e.printStackTrace();
            }
        }

        if (resourceAsStream == null) {
            resourceAsStream = Thread.currentThread()
                                     .getContextClassLoader()
                                     .getResourceAsStream(resourceName);
        }

        if (resourceAsStream == null) {
            // maybe it's in the system classloader?
            resourceAsStream = ClassLoader.getSystemResourceAsStream(resourceName);
        }

        return resourceAsStream;
    }
}
